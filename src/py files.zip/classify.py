# src/classify.py
def classify_component(component_pixels):
    # Placeholder
    # Later: HOG + SVM or CNN
    return "unknown"
